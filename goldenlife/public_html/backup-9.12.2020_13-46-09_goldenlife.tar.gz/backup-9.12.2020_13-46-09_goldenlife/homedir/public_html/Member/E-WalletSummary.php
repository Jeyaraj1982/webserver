<?php include_once("header.php");?>
            <div class="app-main__outer">
                <div class="app-main__inner">
                    <div class="app-page-title">
                        <div class="page-title-wrapper">
                            <div class="page-title-heading">
                                <div class="page-title-icon">
                                    <i class="pe-7s-medal icon-gradient bg-tempting-azure">
                                    </i>
                                </div>
                                <div>E-Wallet Summary
                                   <!-- <div class="page-title-subheading">Choose between regular React Bootstrap tables or advanced dynamic ones.</div> -->
                                </div>
                            </div>
                                 </div>
                    </div> 
                    <div class="main-card mb-3 card">
                        <div class="card-body">
                            <table style="width: 100%;" class="mb-0 table table-bordered">
                                <thead>
                                <tr>
                                    <th>Category</th>
                                    <th>Balance</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                  
                </div>
      <?php include_once("footer.php");?>