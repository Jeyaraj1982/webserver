<?php include_once("header.php");?>
<div class="app-main__outer">
                <div class="app-main__inner">
                    <div class="app-page-title">
                        <div class="page-title-wrapper">
                            <div class="page-title-heading">
                                <div class="page-title-icon">
                                    <i class="pe-7s-medal icon-gradient bg-tempting-azure">
                                    </i>
                                </div>
                                <div>My Members</div>
                            </div>
                        </div>
                    </div>
                    <div class="main-card mb-3 card">
                        <div class="card-body">
                               <?php
                                         $allMembers = $mysql->select("Select * from _tbl_earnings where MemberCode='".$_SESSION['User']['MemberCode']."' order by EarningId Desc limit 0,10");
                                         ?>
                                          <table style="width: 100%;" id="example" class="table table-hover table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Joined</th>
                                    <th>Member Code</th>
                                    <th>Member Name</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($allMembers as $allMember){ ?>
                                <tr>
                                    <td><?php echo $allMember['PlacedOn'];?></td>
                                    <td><?php echo $allMember['PlacedMemberCode'];?></td>
                                    <td><?php echo $allMember['PlacedMemberName'];?></td>
                                     
                                </tr>
                                <?php }?>
                                <?php if (sizeof($allMembers)==0) {?>
                                <tr>
                                    <td colspan="3" style="text-align:center">No Members found</td>
                                </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
              <?php include_once("footer.php");?>