<style>
    .ft-left-nav li a{color:#333}
    /*.ft-left-nav li:hover{background: #dee7fc;}  */
    .ft-left-nav li {color:black;}
    .linkactive1{color:#fff  !important;cursor:pointer;border-bottom:transparent;background:#5983e8;}
    .linkactive1:hover{background:#5983e8;color:#333}
    .linkactive1 a{color:#fff !important;font-weight: bold;} 
</style>
    <div style="width: 15%;">
        <div class="sidemenu" style="width: 170px;margin-left: -19px;margin-bottom: -41px;margin-top: -20px;border-right: 1px solid #eee;">
            <ul class="ft-left-nav fusmyacc_leftnav" style="padding: 0px;list-style: none;">
               <!-- <li class="ft-left-nav-list fusmyacc_leftnavicon2 <?php echo ($page=="E-Pin") ? ' linkactive1 ':'';?>" id="E-Pin" style="padding: 8px 0px 8px 14px;border-bottom:1px solid #eee;">
                    <a id="myaccount_leftnav_a_6"  href="javascript:loadPaymentOption('E-Pin')" class="Notification" style="text-decoration:none"><span>E-Pin</span></a>
                </li>
                <li class="ft-left-nav-list fusmyacc_leftnavicon2 <?php echo ($page=="PayPal") ? ' linkactive1 ':'';?>" id="PayPal" style="padding: 8px 0px 8px 14px;border-bottom:1px solid #eee;">
                    <a id="myaccount_leftnav_a_6"  href="javascript:loadPaymentOption('PayPal')" class="Notification" style="text-decoration:none"><span>PayPal</span></a>
                </li>
                <li disabled="disabled" class="ft-left-nav-list fusmyacc_leftnavicon2 <?php echo ($page=="TestCreditcard ") ? ' linkactive1 ':'';?>" id="TestCreditcard " style="padding: 8px 0px 8px 14px;border-bottom:1px solid #eee;">
                    <a id="myaccount_leftnav_a_6" href="javascript:loadPaymentOption('TestCreditcard')" class="Notification" style="text-decoration:none"><span>Test Credit card </span></a>
                </li>
                <li class="ft-left-nav-list fusmyacc_leftnavicon2 <?php echo ($page=="Bitcoin") ? ' linkactive1 ':'';?>" id="Bitcoin" style="padding: 8px 0px 8px 14px;border-bottom:1px solid #eee;">
                    <a id="myaccount_leftnav_a_6" href="javascript:loadPaymentOption('Bitcoin ')" class="Notification" style="text-decoration:none"><span>Bitcoin</span></a>
                </li>
                <li class="ft-left-nav-list fusmyacc_leftnavicon2 <?php echo ($page=="BankTransaction ") ? ' linkactive1 ':'';?>" id="Bitcoin" style="padding: 8px 0px 8px 14px;border-bottom:1px solid #eee;">
                    <a id="myaccount_leftnav_a_6" href="javascript:loadPaymentOption('BankTransaction')" class="Notification" style="text-decoration:none"><span>Bank Transaction </span></a>
                </li>
                <li class="ft-left-nav-list fusmyacc_leftnavicon2 <?php echo ($page=="Authorized.Net ") ? ' linkactive1 ':'';?>" id="Bitcoin" style="padding: 8px 0px 8px 14px;border-bottom:1px solid #eee;">
                    <a id="myaccount_leftnav_a_6" href="javascript:loadPaymentOption('Authorized.Net')" class="Notification" style="text-decoration:none"><span>Authorized.Net</span></a>
                </li> -->
                 <li class="ft-left-nav-list fusmyacc_leftnavicon2" style="padding: 8px 0px 8px 14px;border-bottom:1px solid #eee;">
                    <a id="myaccount_leftnav_a_6" class="Notification" style="text-decoration:none"><span>E-Pin</span></a>
                </li>
            </ul>
        </div>                                                                      
    </div>