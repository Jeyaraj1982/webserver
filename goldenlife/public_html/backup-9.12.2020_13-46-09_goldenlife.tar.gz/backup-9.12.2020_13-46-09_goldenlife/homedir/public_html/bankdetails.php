<?php include_once("header.php");?>
  <main id="main">
    <section id="about" class="wow fadeInUp">
      <div class="container">
	    <div class="section-header">
          <h2>Bank Details </h2>
         <p>you can pay amount using Cash/Cheque Deposit, IMPS, RTGS, Fund Transfer bellow account.</p>
        </div>
        <div class="row">
          <div class="col-lg-6 about-img content">
            <img src="assets/images/bank_logo.png" alt="">
             <br><br><br><br><br><br><br><br> 
             
          </div>
          <div class="col-lg-6 content">
            <Table cellpadding="5" cellspacing="5" style="background:#fff;border-bottom:3px solid blue;"> 
                <tr>
                    <td colspan="2"><img src="assets/images/iob.png" alt=""></td>
                </tr>
                <tr>
                    <td>&nbsp;&nbsp;Account Name</td>
                    <td><b>Golden Life Society</b></td>
                </tr>
                  <tr>
                    <td>&nbsp;&nbsp;Account Number</td>
                    <td><b>127802000000588</b></td>
                </tr>
                 <tr>
                    <td>&nbsp;&nbsp;IFS Code</td>
                    <td><b>IOBA0001278</b></td>
                </tr>
                <tr>
                    <td style="vertical-align:top;">&nbsp;&nbsp;Branch Details</td>
                    <td >
                     No: 719, Nehruji Road, <br>
                     Villupuram-(Main),<br>
                     Villupuram Dist-605602<br>
                     Tamilnadu<br>
                    </td>
                </tr>
            </table>
          
          </div>
        </div>
      </div>
    </section>  
  </main>
<?php include_once("footer.php");?>
  