<?php include_once("header.php");?>
  <main id="main">
    <section id="about" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>Plan Details</h2>
         <p>We creating awareness among the general public about the natural and organic healthy food is very common. In the same way we are supporting to promote and market the healthy foods by the direct selling system.</p>
        </div>
        <div class="row">
          <div class="col-lg-6 content" style="padding:10px;background:#fff">
          <div style="width:100%;background:#e3fcfa;padding:10px;border:1px solid #a8ede7">
            <h2 style="margin-bottom: 0px;">Leaders PLAN  Entry Amount Rs. 500 </h2>
            <p style="margin-bottom:20px"></p>
            <table style="width:100%;background:#e3fcfa" >
                <tr style="background:#a8ede7">
                    <td style="width:10%;padding:5px;text-align:center;font-weight:bold">No</td>
                    <td style="width:25%;padding:5px;text-align:center;font-weight:bold">Entry</td>
                    <td style="width:25%;padding:5px;text-align:center;font-weight:bold">Payout</td>
                    <td style="width:25%;padding:5px;text-align:center;font-weight:bold">Total</td>
                </tr>
                 <tr>
                    <td style="text-align:center;padding:5px;">1</td>
                    <td style="text-align:center;padding:5px;">5</td>
                    <td style="text-align:right;padding:5px;">Rs. 150</td>
                    <td style="text-align:right;padding:5px;">Rs. 750</td>
                </tr>
                <tr>
                    <td style="text-align:center;padding:5px;">2</td>
                    <td style="text-align:center;padding:5px;">25</td>
                    <td style="text-align:right;padding:5px;">Rs. 30</td>
                    <td style="text-align:right;padding:5px;">Rs. 750</td>
                </tr>
                 <tr>
                    <td style="text-align:center;padding:5px;">3</td>
                    <td style="text-align:center;padding:5px;">125</td>
                    <td style="text-align:right;padding:5px;">Rs. 20</td>
                    <td style="text-align:right;padding:5px;">Rs. 2,500</td>
                </tr>
                 <tr style="font-weight:bold;">
                    <td style="text-align:center;padding:5px;border-top:1px solid #a8ede7"> </td>
                    <td style="text-align:right;padding:5px;border-top:1px solid #a8ede7">155 Nos</td>
                    <td style="text-align:center;padding:5px;border-top:1px solid #a8ede7">***</td>
                    <td style="text-align:right;padding:5px;border-top:1px solid #a8ede7">Rs. 4,000</td>
                </tr>
           </table> 
          </div>
           
           
           <br>
           <div  style="width:100%;background:#fff5d1;padding:10px;border:1px solid #ffe2b5">
           <h2 style="margin-bottom: 0px;">AUTO FUILLING  SYSTEM  </h2>
           <h5 style="font-size: 13px;margin-top: 0px !important;">INCOME Leaders PLAN 1<sup>st</sup> Level 5  Entries </h5>
           
           <table style="width:100%;background:#fff5d1" >
            <tr style="background:#ffe2b5">
                <td style="width:10%;padding:5px;text-align:center;font-weight:bold">No</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Grade</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Nos</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Payout</td>
                <td style="padding:5px;text-align:center;font-weight:bold">20% + Admin</td>
            </tr>
             <tr>
                <td style="text-align:center;padding:5px;">1</td>
                <td style="text-align:left;padding:5px;">1-Star</td>
                <td style="text-align:right;padding:5px;">25 x Rs.50</td>
                <td style="text-align:right;padding:5px;">Rs. 1,250</td>
                <td style="text-align:right;padding:5px;">AF-1 ID + New</td>
            </tr>
            <tr>
                <td style="text-align:center;padding:5px;">2</td>
                <td style="text-align:left;padding:5px;">2-Star</td>
                <td style="text-align:right;padding:5px;">125 x Rs. 70</td>
                <td style="text-align:right;padding:5px;">Rs. 8,750</td>
                <td style="text-align:right;padding:5px;">AF-5 ID + New</td>
            </tr>
             <tr style="font-weight:bold;">
                <td style="text-align:right;padding:5px;border-top:1px solid #ffe2b5"></td>
                <td style="text-align:right;padding:5px;border-top:1px solid #ffe2b5">Total</td>
                <td style="text-align:center;padding:5px;border-top:1px solid #ffe2b5">150 Nos</td>
                <td style="text-align:right;padding:5px;border-top:1px solid #ffe2b5">Rs. 10,000</td>
                <td style="text-align:right;padding:5px;border-top:1px solid #ffe2b5">20% ID=6</td>
            </tr>
           </table> 
           
          <!-- <table style="width:100%;background:#fff5d1" >
            <tr style="background:#ffe2b5">
                <td style="width:10%;padding:5px;text-align:center;font-weight:bold">No</td>
                <td style="width:25%;padding:5px;text-align:center;font-weight:bold">Level</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Payout</td>
                <td style="width:35%;padding:5px;text-align:center;font-weight:bold">Total</td>
            </tr>
             <tr>
                <td style="text-align:center;padding:5px;">1</td>
                <td style="text-align:center;padding:5px;">Star</td>
                <td style="text-align:right;padding:5px;">625 x Rs.50/-</td>
                <td style="text-align:right;padding:5px;">Rs. 31,250/-</td>
            </tr>
            <tr>
                <td style="text-align:center;padding:5px;">2</td>
                <td style="text-align:center;padding:5px;">Double Star</td>
                <td style="text-align:right;padding:5px;">3,125 x Rs. 40/-</td>
                <td style="text-align:right;padding:5px;">Rs. 1,25,000/-</td>
            </tr>
             <tr style="font-weight:bold;">
                <td style="text-align:right;padding:5px;border-top:1px solid #ffe2b5" colspan="3">Total</td>
                <td style="text-align:right;padding:5px;border-top:1px solid #ffe2b5">Rs. 1,56,250/-</td>
            </tr>
           </table>  -->
           </div>
           
           
           <br>
           <div  style="width:100%;background:#e3eef9;padding:10px;border:1px solid #b0d2f2">
           <h2>1.Up Grade Top Up Plan&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[5+5 Nos]  </h2>
           <table style="width:100%;border:2px solid #e3eef9">
            <tr>
                <td></td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">AFMIS-1</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs.1,000 X 12</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs. 12,000</td>
            </tr>                
           </table>
           <br>
           <table style="width:100%;background:#e3eef9" >
            <tr style="background:#b0d2f2">
                <td style="width:10%;padding:5px;text-align:center;font-weight:bold">No</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Grade</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Nos</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Payout</td>
                <td style="padding:5px;text-align:center;font-weight:bold">20% + Admin</td>
            </tr>
             <tr>
                <td style="text-align:center;padding:5px;">3</td>
                <td style="text-align:center;padding:5px;">1-Silver</td>
                <td style="text-align:right;padding:5px;">625 x Rs. 40</td>
                <td style="text-align:right;padding:5px;">Rs. 25,000</td>
                <td style="text-align:right;padding:5px;">AF-25 ID + New</td>
            </tr>
            <tr>
                <td style="text-align:center;padding:5px;">4</td>
                <td style="text-align:center;padding:5px;">2-Silver</td>
                <td style="text-align:right;padding:5px;">3,125 x Rs. 40</td>
                <td style="text-align:right;padding:5px;">Rs. 1,25,000</td>
                <td style="text-align:right;padding:5px;">AF-125 ID + New</td>
            </tr>
             <tr style="font-weight:bold;">
                <td style="text-align:right;padding:5px;border-top:1px solid #b0d2f2"></td>
                <td style="text-align:right;padding:5px;border-top:1px solid #b0d2f2">Total</td>
                <td style="text-align:center;padding:5px;border-top:1px solid #b0d2f2">3750 Nos</td>
                <td style="text-align:right;padding:5px;border-top:1px solid #b0d2f2">Rs. 1,50,500</td>
                <td style="text-align:right;padding:5px;border-top:1px solid #b0d2f2">20% ID=150</td>
            </tr>
           </table>
           <!--<table style="width:100%">
            <tr>
                <td></td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">AFMIS-1</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs.1,000/- X 60</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs. 60,000/-</td>
            </tr>                
           </table>
           <table style="width:100%;background:#e3eef9" >
            <tr style="background:#b0d2f2">
                <td style="width:10%;padding:5px;text-align:center;font-weight:bold">No</td>
                <td style="width:25%;padding:5px;text-align:center;font-weight:bold">Level</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Payout</td>
                <td style="width:35%;padding:5px;text-align:center;font-weight:bold">Total</td>
            </tr>
             <tr>
                <td style="text-align:center;padding:5px;">3</td>
                <td style="text-align:center;padding:5px;">Silver</td>
                <td style="text-align:right;padding:5px;">15,625 x Rs. 30/-</td>
                <td style="text-align:right;padding:5px;">Rs. 4,68,750/-</td>
            </tr>
            <tr>
                <td style="text-align:center;padding:5px;">4</td>
                <td style="text-align:center;padding:5px;">Double Silver</td>
                <td style="text-align:right;padding:5px;">78,125 x Rs. 20/-</td>
                <td style="text-align:right;padding:5px;">Rs. 15,62,500/-</td>
            </tr>
             <tr style="font-weight:bold;">
                <td style="text-align:right;padding:5px;border-top:1px solid #b0d2f2" colspan="3">Total</td>
                <td style="text-align:right;padding:5px;border-top:1px solid #b0d2f2">Rs. 21,87,500/-</td>
            </tr>
           </table>
           -->
           </div>
           <br>
            <div  style="width:100%;background:#edfcf0;padding:10px;border:1px solid #94f7a6">
           <h2>2.Up Grade Top Up Plan&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[5+5+10 Nos]  </h2>
            <table style="width:100%">
            <tr>
                <td></td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">AFMIS-2</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs.3,000/- X 36</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs. 1,08,000</td>
            </tr>                
           </table>
           <table style="width:100%;background:#edfcf0" >
            <tr style="background:#94f7a6">
                <td style="width:10%;padding:5px;text-align:center;font-weight:bold">No</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Grade</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Nos</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Payout</td>
                <td style="padding:5px;text-align:center;font-weight:bold">20% + Admin</td>
            </tr>
             <tr>
                <td style="text-align:center;padding:5px;">5</td>
                <td style="text-align:center;padding:5px;">1-Gold</td>
                <td style="text-align:right;padding:5px;">15,625 x Rs. 60</td>
                <td style="text-align:right;padding:5px;">Rs. 9,37,500</td>
                <td style="text-align:right;padding:5px;">AF-3750 ID + New</td>
            </tr>
            <tr>
                <td style="text-align:center;padding:5px;">6</td>
                <td style="text-align:center;padding:5px;">2-Gold</td>
                <td style="text-align:right;padding:5px;">78,125 x Rs. 80</td>
                <td style="text-align:right;padding:5px;">Rs. 65,50,000</td>
                <td style="text-align:right;padding:5px;">AF-15625 ID + New</td>
            </tr>
             <tr style="font-weight:bold">
                <td style="text-align:right;padding:5px;border-top:1px solid #94f7a6"></td>
                <td style="text-align:right;padding:5px;border-top:1px solid #94f7a6">Total</td>
                <td style="text-align:center;padding:5px;border-top:1px solid #94f7a6">19531 Nos</td>
                <td style="text-align:right;padding:5px;border-top:1px solid #94f7a6">Rs. 71,87,500</td>
                <td style="text-align:right;padding:5px;border-top:1px solid #94f7a6">20% ID=19,375</td>
            </tr>
            
           </table>
           <!--
           <table style="width:100%">
            <tr>
                <td></td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">AFMIS-2</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs.3,000/- X 120</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs. 3,60,000</td>
            </tr>                
           </table>
           <table style="width:100%;background:#edfcf0" >
            <tr style="background:#94f7a6">
                <td style="width:10%;padding:5px;text-align:center;font-weight:bold">No</td>
                <td style="width:25%;padding:5px;text-align:center;font-weight:bold">Level</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Payout</td>
                <td style="width:32%;padding:5px;text-align:center;font-weight:bold">Total</td>
            </tr>
             <tr>
                <td style="text-align:center;padding:5px;">5</td>
                <td style="text-align:center;padding:5px;">Gold</td>
                <td style="text-align:right;padding:5px;">3,90,625 x Rs. 20/-</td>
                <td style="text-align:right;padding:5px;">Rs. 78,12,500/-</td>
            </tr>
            <tr>
                <td style="text-align:center;padding:5px;">6</td>
                <td style="text-align:center;padding:5px;">Double Gold</td>
                <td style="text-align:right;padding:5px;">19,53,125 x Rs. 20/-</td>
                <td style="text-align:right;padding:5px;">Rs. 3,90,62,500/-</td>
            </tr>
             <tr style="font-weight:bold">
                <td style="text-align:right;padding:5px;border-top:1px solid #94f7a6" colspan="3">Total</td>
                <td style="text-align:right;padding:5px;border-top:1px solid #94f7a6">Rs. 4,68,75,000/-</td>
            </tr>
           </table>
           -->
           
              </div>
              <Br>
              <div  style="width:100%;background:#ffeedd;padding:10px;border:1px solid #ef8923">
           <h2>3. Up Grade Top Up Plan&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[5+5+10+10 Nos]  </h2>
           <table style="width:100%">
            <tr>
                <td></td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">AFMIS-3</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs.5,000 X 180</td>
                <td style="text-align:center;font-size:15px;font-weight:bold;;padding:5px;">Rs. 9,00,000</td>
            </tr>                
           </table>
            
              </div>
          </div>
          
          
          <div class="col-lg-6 about-img content" >
            <img style="margin-left:5px" src="https://universityofextraincome.files.wordpress.com/2016/05/mlm-diagram-full11.jpg?w=700" alt="">
            <br><Br>
            <br><Br>
          <!-- <h2>Up Grade Auto Filling Plan Awards </h2>
           <table style="width:100%;background:#faeffc" border="1">
            <tr style="background:#f8dbfc">
                <td style="width:33%;padding:5px;text-align:center;font-weight:bold">Grade</td>
                <td style="width:23%;padding:5px;text-align:center;font-weight:bold">Worth</td>
                <td style=";padding:5px;text-align:center;font-weight:bold">Gifts</td>
            </tr>
             <tr>
                <td style="text-align:left;padding:5px;">Star</td>
                <td style="text-align:right;padding:5px;"> Rs.2,000/-</td>
                <td style="text-align:left;padding:5px;">Cash Award (or)  Gold Watch</td>
            </tr>
              <tr>
                <td style="text-align:left;padding:5px;">Double Star</td>
                <td style="text-align:right;padding:5px;"> Rs.7,500/-</td>
                <td style="text-align:left;padding:5px;">Cash Award (or)  Cellphone</td>
            </tr>
             <tr>
                <td style="text-align:left;padding:5px;">Silver</td>
                <td style="text-align:right;padding:5px;"> Rs. 15,000/-</td>
                <td style="text-align:left;padding:5px;">Cash Award (or)  LED TV</td>
            </tr>
            <tr>
                <td style="text-align:left;padding:5px;">Double Silver</td>
                <td style="text-align:right;padding:5px;">Rs. 25,000/-</td>
                <td style="text-align:left;padding:5px;">Cash Award (or)  Laptop</td>
            </tr>
            <tr>
                <td style="text-align:left;padding:5px;">Gold</td>
                <td style="text-align:right;padding:5px;">Rs. 50,000/-</td>
                <td style="text-align:left;padding:5px;">Cash Award (or) Two Wheeler</td>
            </tr>
            <tr>
                <td style="text-align:left;padding:5px;">Double Gold</td>
                <td style="text-align:right;padding:5px;">Rs. 1,00,000/-</td>
                <td style="text-align:left;padding:5px;">Cash Award (or) Plot</td>
            </tr>
            
           </table>-->
           
             <br><Br><Br>
           <!--<h2> WORKING Leaders PLAN </h2>
           <table style="width:100%;background:#f2fffd" border="1">
            <tr style="background:#d1fcf7">
                <td style="width:5%;padding:5px;text-align:center;font-weight:bold">Code</td>
                <td style="padding:5px;text-align:center;font-weight:bold">Up Grade Auto Filling MIS Plan </td>
                <td style="width:18%;padding:5px;text-align:center;font-weight:bold">Income</td>
                <td style="width:5%;padding:5px;text-align:center;font-weight:bold">Mon</td>
                <td style="width:23%;padding:5px;text-align:center;font-weight:bold">TOTAL</td>
            </tr>
             <tr>
                <td style="text-align:left;padding:5px;">AMIS-1</td>
                <td style="text-align:left;padding:5px;">Up Grade (+5 Entries) Monthly Income Systems</td>
                <td style="text-align:right;padding:5px;">Rs. 1,000/- </td>
                <td style="text-align:center;padding:5px;"> 60</td>
                <td style="text-align:right;padding:5px;">Rs. 60,000/-</td>
            </tr>
              <tr>
                <td style="text-align:left;padding:5px;">AMIS-2</td>
                <td style="text-align:left;padding:5px;">Additional Monthly Income Systems Up Grade (5+5 Entries)</td>
                <td style="text-align:right;padding:5px;">Rs. 3,000/- </td>
                <td style="text-align:center;padding:5px;"> 120</td>
                <td style="text-align:right;padding:5px;">Rs. 3,60,000/-</td>
            </tr>
             <tr>
                <td style="text-align:left;padding:5px;">AMIS-3</td>
                <td style="text-align:left;padding:5px;">Additional Monthly Income Systems Up Grade (5+5+10 Entries) </td>
                <td style="text-align:right;padding:5px;">Rs. 5,000/- </td>
                <td style="text-align:center;padding:5px;"> 120</td>
                <td style="text-align:right;padding:5px;">Rs. 6,00,000/-</td>
            </tr> 
             <tr>
                <td style="text-align:left;padding:5px;">AMIS-4</td>
                <td style="text-align:left;padding:5px;">Additional Monthly Income  Up Grade (5+5+10+10 Entries)</td>
                <td style="text-align:right;padding:5px;">Rs. 5,000/- </td>
                <td style="text-align:center;padding:5px;"> 180</td>
                <td style="text-align:right;padding:5px;">Rs. 9,00,000/-</td>
            </tr>  
           </table> -->
               
      
             
          </div>
        </div>
      </div>
    </section>  
  </main>
<?php include_once("footer.php");?>
  