<footer id="footer" style="background:#333">
    <div class="container">
      <div class="copyright"><a href="terms" style="color:#fff">Terms and conditions</a></div>
      <div class="copyright">&copy; Copyright <strong>Gold Life Society</strong>. All Rights Reserved</div>
      <div class="credits">Powered by <a href="http://www.goldlifesociety.co.in">Golden Life Society</a></div>
    </div>
  </footer><!-- #footer -->
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- JavaScript  -->
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/jquery/jquery.min.js"></script>
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/jquery/jquery-migrate.min.js"></script>
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/easing/easing.min.js"></script>
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/superfish/hoverIntent.js"></script>
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/superfish/superfish.min.js"></script>
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/wow/wow.min.js"></script>
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/magnific-popup/magnific-popup.min.js"></script>
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/lib/sticky/sticky.js"></script> 
 <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/contact/jqBootstrapValidation.js"></script>
 <!--<script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/contact/contact_me.js"></script>-->
  <script src="https://webthemez.com/demo/topper-corporate-bootstrap-4-website-template/js/main.js"></script>
</body>
</html>