<?php include_once("header.php");?>
  <main id="main">
    <section id="about" class="wow fadeInUp">
      <div class="container">
	    <div class="section-header">
          <h2>About Us</h2>
         <p>Creating awareness among the public about the natural, organic and healthy food is very common  We are supporting to promote and market healthy foods by direct selling system.</p>
        </div>
        <div class="row">
          <div class="col-lg-6 about-img content">
            <img src="assets/images/about-img.png" alt="">
             <br><br><br><br><br><br><br><br> 
             
          </div>
          <div class="col-lg-6 content">
           <h2>Mission </h2>
             <ul>
              <li><i class="icon ion-ios-checkmark-outline"></i>Naturopathy are herbal medicines continue to be a popular Healthcare choice with the general public for health maintenance and welfare beings.</li>
              <li><i class="icon ion-ios-checkmark-outline"></i>We are very aware that human society will be safest avenue, if it is adopted only natural lifestyle.</li>
              <li><i class="icon ion-ios-checkmark-outline"></i>So we joined hands with those who are promoting and marketing natural and herbal health care products.</li>
            </ul>
             <h2>Vision </h2>
             <ul>
              <li><i class="icon ion-ios-checkmark-outline"></i>Nowadays around the world, the health and hygienic situation are going down to very bottom level, due to unhygienic and adulterated food items.</li>
              <li><i class="icon ion-ios-checkmark-outline"></i>We are supporting and promoting healthy and organic foods with echo-friendly environment.</li>
              <li><i class="icon ion-ios-checkmark-outline"></i>We are helping to market natural and non chemical based food products throughout India.</li>
            </ul>
            <h2>Oblect of the Golden Life Society</h2>
            <ul>
              <li><i class="icon ion-ios-checkmark-outline"></i>Conducting village councils, youth groups, women's groups, Village development programs..</li>
              <li><i class="icon ion-ios-checkmark-outline"></i>Helping people though self-help people organization.</li>
              <li><i class="icon ion-ios-checkmark-outline"></i>Targeting the majority of the people.</li>
              
              <li><i class="icon ion-ios-checkmark-outline"></i>Bridge the gap between villagers.</li>
              <li><i class="icon ion-ios-checkmark-outline"></i>Improve ground water resources.</li>
              
              
              <li><i class="icon ion-ios-checkmark-outline"></i>Planting palm trees on both sides of the roads.</li>
              <li><i class="icon ion-ios-checkmark-outline"></i>Providing health facilities at local festivals and markets.</li>
              
              <li><i class="icon ion-ios-checkmark-outline"></i>Creating and maintaining courses.</li>
              <li><i class="icon ion-ios-checkmark-outline"></i>Establishing formal, social and adult education centers.</li>
            </ul>
          
          </div>
        </div>
          <img src="assets/summary.png">
      </div>
    </section>  
  </main>
<?php include_once("footer.php");?>
  