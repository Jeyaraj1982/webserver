<?php include_once("header.php");?>
  <main id="main">
    <section id="about" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>Terms</h2>
         <ul style="line-height: 25px;font-size: 13px;">
            <li style="padding:10px !important">5% சேவை கட்டணமாகவும், 5% நிர்வாகக் கட்டணமாகவும், 10% அல்லது TDS ஆகவும், மொத்தமாக செலுத்த வேண்டிய கமிஷன்களிலிருந்து, அரசாங்கத்தால் விதிக்கப்பட்டால், பொருந்தக்கூடிய சேவை வரியைக் குறைப்பது (அல்லது) கூடுதல் இருந்தால் தாங்களே செலுத்த வேண்டும் என்று விநியோகஸ்தர்களுக்கு தெரியப்படுத்தப்பட்டுள்ளது.</li>
            <li style="padding:10px !important">Agreement இந்த உடன்படிக்கை தொடர்பாக எழும் எந்தவொரு தகராறு, வேறுபாடுகள் அல்லது உரிமை கோரல் பிணைப்பு நடுவர் மன்றத்திற்கு சமர்ப்பிக்கப்படும், மேலும் விரைவான பாதை நடுவர் மீது மாற்று தகராறு தீர்வுக்கான சர்வதேச மையத்தின் விதிகள் மற்றும் ஒழுங்குமுறைகளுக்கு ஏற்ப நியமிக்கப்பட்ட ஒரே நடுவர் பரிந்துரைக்கப்படுவார். . அத்தகைய நடுவர் இடம் மதுரையில் இருக்கும், மேலும் நடுவரின் விருது அனைத்து தரப்பினருக்கும் இறுதியானது. இந்த நடுவர் ஒப்பந்தம் மற்றும் அதிலிருந்து எழும் எந்தவொரு விருது தொடர்பாகவும் விழுப்புரத்தில் உள்ள நீதி மன்றங்களுக்கு அதிகார வரம்பு இருக்கும்.</li>
            <li style="padding:10px !important">Read நிறுவனத்தின் அனைத்து விதிமுறைகளும் நிபந்தனைகளும் ஒரே மாதிரியாக ஒப்புக் கொள்ள வேண்டும். பதிவு ஆன்லைன் மூலம் செய்யப்பட்டிருந்தால், உருவாக்கப்பட்ட இந்த மின்னணு ஊடகம் தனிநபரால் ஏற்றுக்கொள்ளப்படுவதைக் கருதுகிறது. எனவே, மின்னணு சமர்ப்பிப்புக்கு எந்த கையொப்பமும் தேவையில்லை.</li>
            <li style="padding:10px !important">Will deduct 5% as Service Charges and 5% as Administration Charges  and 10% or as TDS from their total payable commissions, which includes applicable service tax, The extra ones have to pay for themselves  if any imposed by government.</li>
            <li style="padding:10px !important">Any dispute, differences or claim arising out of as in connection with this agreement shall be submitted to binding arbitration and shall be referred to the sole Arbitrator appointed in accordance with the rules and regulation of international center for Alternate Dispute Resolution on a fast tract arbitration. The venue of such arbitration shall be at Madurai and the award of the Arbitrator shall be final and binding on all parties. The courts at Villupuram shall along have jurisdiction in relation to this Arbitration Agreement and any award arising therefrom.</li>
            <li style="padding:10px !important"> I have read and under should all Terms & Conditions of the company and Agree with the same. If the registration has been done through online, this electronic media generated presumes the acceptance by the individual. Hence, electronic submission does not require any signature.</li>
         </ul>        
        </div>
        <div class="row">
           
           
        </div>
      </div>
    </section>  
  </main>
<?php include_once("footer.php");?>
  