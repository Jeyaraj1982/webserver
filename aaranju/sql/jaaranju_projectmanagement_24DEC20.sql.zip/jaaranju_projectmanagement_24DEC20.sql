/*
SQLyog Enterprise - MySQL GUI v8.18 
MySQL - 5.7.32 : Database - aaranju_projectmanagement
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`aaranju_projectmanagement` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `aaranju_projectmanagement`;

/*Table structure for table `_tblAttachment` */

DROP TABLE IF EXISTS `_tblAttachment`;

CREATE TABLE `_tblAttachment` (
  `AttachmentID` int(11) NOT NULL AUTO_INCREMENT,
  `IssueID` int(11) DEFAULT '0',
  `prototypeID` int(11) DEFAULT '0',
  `StakeHolderID` int(11) DEFAULT '0',
  `ProjectID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `FileName` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `IsDirect` int(11) DEFAULT NULL,
  PRIMARY KEY (`AttachmentID`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `_tblAttachment` */

insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (1,0,NULL,2,3,24,'_1606712750c5f6a4c7-93b9-4b40-9071-d464dbb491c6.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (2,0,NULL,5,3,24,'_1606713021capture.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (3,0,NULL,6,3,24,'_1606713108capture1.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (4,18,0,0,3,24,'_1606713330c5f6a4c7-93b9-4b40-9071-d464dbb491c6.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (5,22,0,0,3,24,'_1606713407capture.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (6,23,0,0,3,24,'_1606713441capture1.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (7,25,0,0,2,23,'_1607073901screenshot_20201204-144501.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (8,25,0,0,2,23,'_1607073901screenshot_20201204-144511.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (9,26,0,0,2,23,'_1607147149screenshot_20201205-104427.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (10,27,0,0,2,23,'_16071475982.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (11,28,0,0,2,23,'_16071482041.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (12,29,0,0,2,23,'_16071487943.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (13,30,0,0,2,23,'_16071693434.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (14,34,0,0,1,23,'_16073228875.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (15,35,0,0,2,23,'_16074045867.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (16,37,0,0,2,23,'_1607405946screenshot_20201208-105503.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (17,37,0,0,2,23,'WhatsApp Image 2020-12-08 at 11.25.17 AM.jpeg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (18,37,0,0,2,23,'WhatsApp Image 2020-12-08 at 11.24.07 AM.jpeg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (19,38,0,0,2,23,'_16074082028.jpg',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (20,39,0,0,1,23,'_16074095349.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (21,40,0,0,1,23,'_160741124310.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (22,41,0,0,17,23,'_1607502986jewellery work 1.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (23,42,0,0,17,23,'_1607506481jewellery work.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (24,43,0,0,17,23,'_16075075465.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (25,44,0,0,17,23,'_16075078475.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (26,45,0,0,17,23,'_16075083666.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (27,46,0,0,17,23,'_16075089687.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (28,49,0,0,17,23,'_16075146688.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (29,52,0,0,1,23,'_16075794039.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (30,53,0,0,17,23,'_16075796029.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (31,54,0,0,17,23,'_160758357310.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (32,55,0,0,17,23,'_160758436711.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (33,56,0,0,17,23,'_160758563813.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (34,57,0,0,17,23,'_160758622414.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (35,58,0,0,17,23,'_160758693815.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (36,59,0,0,17,23,'_160758720116.png',1);
insert  into `_tblAttachment`(`AttachmentID`,`IssueID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (37,60,0,0,17,23,'_160759928317.png',1);

/*Table structure for table `_tblAttachmentReply` */

DROP TABLE IF EXISTS `_tblAttachmentReply`;

CREATE TABLE `_tblAttachmentReply` (
  `AttachmentID` int(11) NOT NULL AUTO_INCREMENT,
  `IssueID` int(11) DEFAULT '0',
  `ReplyID` int(11) DEFAULT '0',
  `prototypeID` int(11) DEFAULT '0',
  `StakeHolderID` int(11) DEFAULT '0',
  `ProjectID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `FileName` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `IsDirect` int(11) DEFAULT NULL,
  PRIMARY KEY (`AttachmentID`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `_tblAttachmentReply` */

insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (13,26,0,0,0,2,3,'_1607165338issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (14,26,0,0,0,2,3,'_1607166290issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (15,26,0,0,0,2,3,'_1607166393issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (16,26,0,0,0,2,3,'_1607166719issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (17,26,0,0,0,2,3,'_1607166817issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (18,26,0,0,0,2,3,'_1607167169issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (19,26,0,0,0,2,3,'_1607167197issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (20,26,0,0,0,2,3,'_1607167239issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (21,26,0,0,0,2,3,'_1607167324issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (22,26,0,0,0,2,3,'_1607167358issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (23,26,0,0,0,2,3,'_1607167417issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (24,26,0,0,0,2,3,'_1607167982issue_26.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (25,27,0,0,0,2,3,'_1607182157issue_27_1.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (26,28,0,0,0,2,3,'_1607187858issue_28.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (27,28,0,0,0,2,3,'_1607187858issue_28_1.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (28,36,0,0,0,2,3,'_1607406366issue_36.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (29,42,0,0,0,17,3,'_1607510010issue_42.png',1);
insert  into `_tblAttachmentReply`(`AttachmentID`,`IssueID`,`ReplyID`,`prototypeID`,`StakeHolderID`,`ProjectID`,`UserID`,`FileName`,`IsDirect`) values (30,45,0,0,0,17,3,'_1607615310issue_45.png',1);

/*Table structure for table `_tblIssues` */

DROP TABLE IF EXISTS `_tblIssues`;

CREATE TABLE `_tblIssues` (
  `IssueID` int(11) NOT NULL AUTO_INCREMENT,
  `IssuePostedBy` int(11) DEFAULT NULL,
  `IssuePostedByName` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `IssueCreatedOn` datetime DEFAULT NULL,
  `IssueStatus` int(11) DEFAULT NULL COMMENT '1-Open 2 Close',
  `ProjectID` int(11) DEFAULT NULL,
  `ProjectName` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `IssueTitle` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `IssueDescription` text COLLATE latin1_general_ci,
  `IssueAssignedBy` int(2) DEFAULT NULL,
  `IssueAssingedByName` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `DeveloperID` int(11) DEFAULT NULL,
  `DeveloperName` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `ClosedOn` datetime DEFAULT NULL,
  `VerifyAID` int(11) DEFAULT '0',
  `VerifiedA` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `VerifiedAOn` datetime DEFAULT NULL,
  `VerifyBID` int(11) DEFAULT NULL,
  `VerifiedB` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `VerifiedBOn` datetime DEFAULT NULL,
  PRIMARY KEY (`IssueID`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `_tblIssues` */

insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (1,23,'Vickneswari ','2020-11-27 19:20:59',2,1,'Trip78-Web','Need DELETE option in main category','',1,'Jeyaraj',3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (2,23,'Vickneswari ','2020-11-27 19:21:09',2,1,'Trip78-Web','All sub tours contain the same packages when we create a new sub tour before adding packages in each sub tour.','',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (3,23,'Vickneswari ','2020-11-27 19:21:18',2,1,'Trip78-Web','Sub tour -> Add package ->Price -> need (,) separated option to enter price.','',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (4,23,'Vickneswari ','2020-11-27 19:21:26',2,1,'Trip78-Web','Sub tour -> Add package -> Package Name  ->  Need Repetition','',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (5,23,'Vickneswari ','2020-11-27 19:21:33',2,1,'Trip78-Web','International Tours ->Cambodia -> 5n 6d Cambodia -> Sub category -> Need Days option.','',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (6,23,'Vickneswari ','2020-11-27 19:21:40',2,1,'Trip78-Web','When trying to delete a sub tour, the processing box is loading for a long time.','',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (7,23,'Vickneswari ','2020-11-27 19:21:47',2,1,'Trip78-Web','Tours -> Manage Package -> New Package -> image changes than the one we selected','',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (8,23,'Vickneswari ','2020-11-27 19:21:55',2,1,'Trip78-Web','Packages -> View -> Add day & event -> Event description -> sometimes not visible (Column is empty).','',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (9,23,'Vickneswari ','2020-11-27 19:22:13',2,1,'Trip78-Web','Address Change','Plot No: 15 , Devdas Nagar,South ByePass Road,Near Passport Office(PSK),Tirunelveli-627005\r\n	9626687878',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (10,23,'Vickneswari ','2020-11-27 19:22:45',2,1,'Trip78-Web','Enquiry Form Update','no of infant (below 2 yr)\r\nno of children (age 3-12)',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (11,23,'Vickneswari ','2020-11-27 19:22:52',2,1,'Trip78-Web','Enquiry - Logo in empty space','',NULL,NULL,3,'Jayanthi','2020-11-28 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (12,23,'Vickneswari ','2020-11-27 19:23:32',1,1,'Trip78-Web','Booking mail ','Every Booking Inquiry send to trip78nellai@gmail.com',NULL,NULL,3,'Jayanthi','0000-00-00 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (13,23,'Vickneswari ','2020-11-27 19:23:38',1,1,'Trip78-Web','search option ','',NULL,NULL,3,'Jayanthi',NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (14,23,'Vickneswari ','2020-11-27 19:23:59',1,2,'Trip78-Mobile','APK: Price does not visible in APK but it is visible in website','',NULL,NULL,3,'Jayanthi',NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (15,23,'Vickneswari ','2020-11-27 19:24:07',1,2,'Trip78-Mobile','APK: Few main Categories only displays in APK.','',NULL,NULL,3,'Jayanthi',NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (16,23,'Vickneswari ','2020-11-27 19:24:17',1,2,'Trip78-Mobile','APK: Search bar','',NULL,NULL,3,'Jayanthi',NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (17,24,'tksd','2020-11-30 10:44:56',1,4,'abj-MobileWeb','telegram integaration','need to update\r\n\r\n1) wallet credit/debit\r\n2) bill payment update/reverse ',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (18,24,'tksd','2020-11-30 10:45:30',1,3,'tksd-MobileWeb','telegram integaration wrong notification to client','one client received other clients notifications when Tn-police bill payment done ',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (19,24,'tksd','2020-11-30 10:45:47',1,3,'tksd-MobileWeb','agent list link need to change','https://tksdonlineservice.in/admin/app/dashboard.php?action=Agents/List (wrong on dashboard icon press)\r\n\r\ninstead of below link\r\n\r\nhttps://tksdonlineservice.in/admin/app/dashboard.php?action=Users/List (correct)',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (20,24,'tksd','2020-11-30 10:46:16',1,3,'tksd-MobileWeb','reverse remarks printed on client side txn','when bills are reversed the reason need to print ',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (21,24,'tksd','2020-11-30 10:46:28',1,4,'abj-MobileWeb','reverse remarks printed on client side txn','when bills are reversed the reason need to print ',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (22,24,'tksd','2020-11-30 10:46:47',1,3,'tksd-MobileWeb','mark as credit','remove nick name from wallet credit both admin and dealer on credit sales. Take the client name as a nick name. ',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (23,24,'tksd','2020-11-30 10:47:21',1,3,'tksd-MobileWeb','delete option there. but not working in credit sales from admin side','unable delete wallet refill credit sales only on admin side. Dealer side working.',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (24,23,'Vickneswari ','2020-12-04 14:33:45',2,2,'Trip78-MobileWeb','INTERNATIONAL TOURS - VIEW ALL','While opening view all in International tours, Specialty tours, Indian tours etc...(All tours), Indian tours packages are listed',NULL,NULL,3,'Jayanthi','2020-12-05 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (25,23,'Vickneswari ','2020-12-04 14:55:01',2,2,'Trip78-MobileWeb','corrections done only on themes..','adding of days, leaving place, joining place have not done on any other tours except destination by themes...',NULL,NULL,3,'Jayanthi','2020-12-05 00:00:00',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (26,23,'Vickneswari ','2020-12-05 11:15:49',2,2,'Trip78-MobileWeb','Adding Package prices in all tours','Package ( for ex: Australia package) -> view details -> Please add price for each packages\r\n',NULL,NULL,3,'Jayanthi','2020-12-05 17:03:01',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (27,23,'Vickneswari ','2020-12-05 11:23:18',2,2,'Trip78-MobileWeb','ADMIN PANEL - Add package - INCLUSION & EXCLUSION field','please add a new field in ADD PACKAGE form, for entering inclusion & exclusion...adding this feature is useful for the next task..\r\n\r\nI have enclosed a reference image ',NULL,NULL,3,'Jayanthi','2020-12-05 20:59:15',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (28,23,'Vickneswari ','2020-12-05 11:33:24',2,2,'Trip78-MobileWeb','Views of each packages','When opening each package (Australia package) -> view details -> please add 3 separate columns after joining place & leaving place. And remove the remaining things. Instead please insert the following..\r\n\r\n3 columns are as follows..\r\n\r\n1) ITINERARY 2) ENQUIRY 3) INCLUSION & EXCLUSION\r\nI have enclosed a reference image..\r\n\r\n1) by default all ITINERARY contents will have to be displayed..\r\n2) like wise when I click enquiry, enquiry form has to be displayed \r\n3) for Inclusion & Exclusion, recover the fields from db ( admin panel - add package ) and post here..\r\n',NULL,NULL,3,'Jayanthi','2020-12-05 22:34:17',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (29,23,'Vickneswari ','2020-12-05 11:43:14',1,2,'Trip78-MobileWeb','Manual search & Voice Search','while working on manual search option please insert voice search also',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (30,23,'Vickneswari ','2020-12-05 17:25:43',2,2,'Trip78-MobileWeb','Package name - case sensitive ','Please look at the below attachment, the package title should be as same as the one indicated below in the attachment..',NULL,NULL,3,'Jayanthi','2020-12-05 20:46:17',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (31,23,'Vickneswari ','2020-12-07 10:37:44',1,2,'Trip78-MobileWeb','Error in Inclusion & Exclusion field','Data given under this field not getting saved.',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (32,23,'Vickneswari ','2020-12-07 10:52:50',1,1,'Trip78-Web','BACK button not goes back to the exact previous page','International Package -> View sub tours -> Australia Package -> View -> Back ( Not goes back to the exact previous page )\r\nInternational Package -> View sub tours -> Australia Package -> View Package -> 6N 7D Australia -> View -> Back ( Not goes back to the exact previous page )',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (33,23,'Vickneswari ','2020-12-07 12:01:29',1,2,'Trip78-MobileWeb','ui','',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (34,23,'Vickneswari ','2020-12-07 12:04:47',1,1,'Trip78-Web','UI','Please go through the attachment and work on it..\r\n\r\nI have given a sample image for home page ( how all the tours have to be displayed )..\r\nFor Destination by themes, all subcategories have to displayed in Home page itself...\r\nAll other tours have to be displayed as like (Indian tours, World tours, Specialty tours etc....)\r\n\r\nplease ping me if you have any doubts....\r\n\r\n',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (35,23,'Vickneswari ','2020-12-08 10:46:26',1,2,'Trip78-MobileWeb','MENU BAR','The side bar has to be as shown in image',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (36,23,'Vickneswari ','2020-12-08 10:53:43',2,2,'Trip78-MobileWeb','MENU BAR - links for social media','Facebook  - https://www.facebook.com/trip.seveneight.3\r\nTwitter      - https://twitter.com/Trip784\r\nPinterest  - https://in.pinterest.com/trip78mail/_saved/\r\nInstagram -https://www.instagram.com/trip_seveneight/\r\nTumblr       - http://trip78.tumblr.com/',NULL,NULL,3,'Jayanthi','2020-12-08 11:16:05',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (37,23,'Vickneswari ','2020-12-08 11:09:06',2,2,'Trip78-MobileWeb','ITINERARY - order','Order mismatches ..\r\n( Indian tour -> Pelling -> 9N 10D Gangtok )',NULL,NULL,3,'Jayanthi','2020-12-08 11:31:11',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (38,23,'Vickneswari ','2020-12-08 11:46:42',1,2,'Trip78-MobileWeb','INTERCHANGING OF DAYS | NIGHTS to NIGHTS |  DAYS ','Please interchange days | nights to nights | days....',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (39,23,'Vickneswari ','2020-12-08 12:08:54',1,1,'Trip78-Web','admin panel - edit package','In edit package, dropdown box of days, nights only contains 10 numbers.... Please make it up to 20...',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (40,23,'Vickneswari ','2020-12-08 12:37:23',1,1,'Trip78-Web','Admin panel - Agent - Manage Agent','Please make it visible ( here it shows only the total count, not each and individual enquiries ) all the enquiries assigned to each of the agents...IN DETAIL \r\n\r\nfor ex: Agent named Marathi has 6 enquiries, I want to see all the enquiries in detailed manner..',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (41,23,'Vickneswari ','2020-12-09 14:06:26',2,17,'Jewell-app','Exception','Exception occurs after login',NULL,NULL,3,'Jayanthi','2020-12-10 21:22:16',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (42,23,'Vickneswari ','2020-12-09 15:04:41',2,17,'Jewell-app','Main Menu - admin login','1) 2 menu bars shows at the top\r\n2) Need to change Imax software into Nexify software\r\n3) Need to change the customer care number to 9442461549\r\n4) Real time date and time is not working',NULL,NULL,3,'Jayanthi','2020-12-09 16:03:29',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (43,23,'Vickneswari ','2020-12-09 15:22:26',1,17,'Jewell-app','Companies -> New ( New company creation )','1) Please make Company Name, Financial yearF, Financial yearT as Mandatory Fields...\r\n2) Please add 3 new columns , Mobile Number, Print Name, Short Name\r\n',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (44,23,'Vickneswari ','2020-12-09 15:27:27',1,17,'Jewell-app',' New company creation - Ph validation','1) Please do validation for Phone number and Mobile Number',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (45,23,'Vickneswari ','2020-12-09 15:36:06',2,17,'Jewell-app','Listing of companies ','please add the following columns in listing of all companies,,,\r\n\r\n1) Branch code\r\n2) Address\r\n3) Phone Number\r\n4) Financial yearF\r\n5) Financial yearT',NULL,NULL,3,'Jayanthi','2020-12-10 21:18:29',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (46,23,'Vickneswari ','2020-12-09 15:46:08',1,17,'Jewell-app','Edit Company','When try to update company information, the error message is showing..',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (47,23,'Vickneswari ','2020-12-09 16:14:11',1,17,'Jewell-app','Delete company','When try to delete a company after a user has assigned, the company gets deleted..',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (48,23,'Vickneswari ','2020-12-09 16:43:14',1,2,'Trip78-MobileWeb','Email id ','trip78otp@gmail.com (for otp purpose)\r\n( super admin e-mail ) trip78mail@gmail.com - This email is for sending a parallel notification for every enquiry to super admin',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (49,23,'Vickneswari ','2020-12-09 17:21:08',1,17,'Jewell-app','Companies, Users ','There is a small gap b/w the menu and list of companies & users\r\n',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (50,23,'Vickneswari ','2020-12-10 10:46:25',1,17,'Jewell-app','Unhandled exception ','Unhandled exception occurs when opening the following tabs masters..\r\n\r\n1) Item master\r\n2) Country\r\n3) State \r\n4) HSN\r\n5) Groups\r\n6) Product Type\r\n7) Ledger\r\n8) Groups',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (51,23,'Vickneswari ','2020-12-10 11:02:59',1,17,'Jewell-app','Masters -> ','',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (52,23,'Vickneswari ','2020-12-10 11:20:03',1,1,'Trip78-Web','Country master','Country master refused to save the data..error occurs while saving',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (53,23,'Vickneswari ','2020-12-10 11:23:22',1,17,'Jewell-app','Country master','Country master refused to save the data...error occurs when saving ',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (54,23,'Vickneswari ','2020-12-10 12:29:33',2,17,'Jewell-app','HSN/SAC MASTER','please make the HSN/SAC column as a mandatory field and indicate by using * ',NULL,NULL,3,'Jayanthi','2020-12-10 16:48:58',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (55,23,'Vickneswari ','2020-12-10 12:42:47',2,17,'Jewell-app','Group name','please make group name as unique ',NULL,NULL,3,'Jayanthi','2020-12-10 16:50:46',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (56,23,'Vickneswari ','2020-12-10 13:03:58',1,17,'Jewell-app','delete master','After a new item master is created, when try to delete Product Type, HSN/SAC,  Groups, it gets deleted....',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (57,23,'Vickneswari ','2020-12-10 13:13:44',2,17,'Jewell-app','Account Group','Account group already exists alert message shows like Country code already exists..',NULL,NULL,3,'Jayanthi','2020-12-10 21:08:47',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (58,23,'Vickneswari ','2020-12-10 13:25:38',2,17,'Jewell-app','State Name ','State -> Edit -> country name ->  shows the same country name but given 3 different countries in country master',NULL,NULL,3,'Jayanthi','2020-12-10 21:07:33',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (59,23,'Vickneswari ','2020-12-10 13:30:01',2,17,'Jewell-app','Adding New State - ','same country name is repeating while entering new state ',NULL,NULL,3,'Jayanthi','2020-12-10 21:05:34',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (60,23,'Vickneswari ','2020-12-10 16:51:23',2,17,'Jewell-app','Spelling mistake ','Inventory groups -> new ',NULL,NULL,3,'Jayanthi','2020-12-10 20:54:04',0,NULL,NULL,NULL,NULL,NULL);
insert  into `_tblIssues`(`IssueID`,`IssuePostedBy`,`IssuePostedByName`,`IssueCreatedOn`,`IssueStatus`,`ProjectID`,`ProjectName`,`IssueTitle`,`IssueDescription`,`IssueAssignedBy`,`IssueAssingedByName`,`DeveloperID`,`DeveloperName`,`ClosedOn`,`VerifyAID`,`VerifiedA`,`VerifiedAOn`,`VerifyBID`,`VerifiedB`,`VerifiedBOn`) values (61,23,'Vickneswari ','2020-12-11 12:20:42',1,18,'Trip78-Webadmin','Emails and Passwords','trip78otp@gmail.com\r\nPass : Check2020\r\n\r\ntrip78mail@gmail.com\r\nPass: Mail2020',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `_tblIssues_reply` */

DROP TABLE IF EXISTS `_tblIssues_reply`;

CREATE TABLE `_tblIssues_reply` (
  `ReplyID` int(11) NOT NULL AUTO_INCREMENT,
  `ReplyDateTime` datetime DEFAULT NULL,
  `IssueID` int(11) DEFAULT NULL,
  `Description` text,
  `PostedBy` int(11) DEFAULT NULL,
  `PostedByName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ReplyID`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

/*Data for the table `_tblIssues_reply` */

insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (1,'2020-12-05 16:18:58',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (2,'2020-12-05 16:21:22',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (3,'2020-12-05 16:27:06',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (4,'2020-12-05 16:32:19',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (5,'2020-12-05 16:34:49',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (6,'2020-12-05 16:36:32',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (7,'2020-12-05 16:39:32',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (8,'2020-12-05 16:41:58',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (9,'2020-12-05 16:43:36',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (10,'2020-12-05 16:49:28',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (11,'2020-12-05 16:49:55',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (12,'2020-12-05 16:50:38',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (13,'2020-12-05 16:52:03',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (14,'2020-12-05 16:52:37',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (15,'2020-12-05 16:53:35',26,'Issue Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (16,'2020-12-05 17:03:01',26,'Issue Fixed',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (17,'2020-12-05 18:05:31',30,'Fixed.\r\nView Packages & View Package.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (18,'2020-12-05 20:46:17',30,'Issue Fixed',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (19,'2020-12-05 20:59:15',27,'Issue Fixed\r\nAdmin Side Added Functionality\r\n\r\nAlso displayed Web & Mobile App\r\n\r\nif INCLUSION & EXCLUSION Stored, it displays \r\n',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (20,'2020-12-05 22:34:17',28,'Issue fixed both web and mobile.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (21,'2020-12-08 11:16:05',36,'Url Link added.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (22,'2020-12-08 11:31:11',37,'Fixed\r\nMobile View\r\nWebsite View',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (23,'2020-12-09 16:03:29',42,'Completed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (24,'2020-12-10 16:48:58',54,'Fixed.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (25,'2020-12-10 16:50:46',55,'Not allow Duplicate\r\nAdd Group, Edit Group',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (26,'2020-12-10 20:54:04',60,'Updated Edit and New Form',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (27,'2020-12-10 21:05:34',59,'Old app it allows, but new app not allows',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (28,'2020-12-10 21:07:33',58,'Fixed',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (29,'2020-12-10 21:08:47',57,'Fixed New and Edit Form',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (30,'2020-12-10 21:18:29',45,'Updated.',3,'Jayanthi');
insert  into `_tblIssues_reply`(`ReplyID`,`ReplyDateTime`,`IssueID`,`Description`,`PostedBy`,`PostedByName`) values (31,'2020-12-10 21:22:16',41,'Fixed ',3,'Jayanthi');

/*Table structure for table `_tblPStakeHolderTask` */

DROP TABLE IF EXISTS `_tblPStakeHolderTask`;

CREATE TABLE `_tblPStakeHolderTask` (
  `TaskID` int(11) NOT NULL AUTO_INCREMENT,
  `TaskPostedBy` int(11) DEFAULT NULL,
  `TaskPostedByName` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `TaskCreatedOn` datetime DEFAULT NULL,
  `TaskStatus` int(11) DEFAULT NULL COMMENT '1-Open 2 Close',
  `ProjectID` int(11) DEFAULT NULL,
  `ProjectName` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `TaskTitle` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `TaskDescription` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `CompletedOn` datetime DEFAULT NULL,
  `CompletedByID` int(11) DEFAULT NULL,
  `CompletedByName` varchar(255) DEFAULT NULL,
  `LastUpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`TaskID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `_tblPStakeHolderTask` */

insert  into `_tblPStakeHolderTask`(`TaskID`,`TaskPostedBy`,`TaskPostedByName`,`TaskCreatedOn`,`TaskStatus`,`ProjectID`,`ProjectName`,`TaskTitle`,`TaskDescription`,`CompletedOn`,`CompletedByID`,`CompletedByName`,`LastUpdatedOn`) values (7,25,'Subbu','2020-11-30 09:22:29',1,1,'Trip78-Web','Agent Concept in Admin Area','1. Create Agent\r\n2. Edit Agent\r\n3. List Agents\r\n4. View Agent + Add/Remove Pin-codes\r\n5. Agent Login\r\n\r\n6. Agent Login (active agents allow to login)\r\n6.1 My Profile\r\n6.2 Change Password\r\n6.3 My Enquires-> View\r\n6.4 Dashboard : Count my enquires based on assigned pincodes\r\n',NULL,NULL,NULL,NULL);

/*Table structure for table `_tblPStakeHolderTaskItems` */

DROP TABLE IF EXISTS `_tblPStakeHolderTaskItems`;

CREATE TABLE `_tblPStakeHolderTaskItems` (
  `TaskItemID` int(11) NOT NULL AUTO_INCREMENT,
  `TaskID` int(11) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `TaskDescription` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `Hrs` int(11) DEFAULT NULL,
  `Mins` int(11) DEFAULT NULL,
  `IsActive` int(11) DEFAULT '1',
  `Deactivated` datetime DEFAULT NULL,
  PRIMARY KEY (`TaskItemID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `_tblPStakeHolderTaskItems` */

/*Table structure for table `_tblProjectAssign` */

DROP TABLE IF EXISTS `_tblProjectAssign`;

CREATE TABLE `_tblProjectAssign` (
  `AssignID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `ProjectID` int(11) DEFAULT NULL,
  `AddedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`AssignID`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `_tblProjectAssign` */

insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (1,23,1,'2020-11-28 00:00:00');
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (2,23,2,'2020-11-28 00:00:00');
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (3,1,1,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (4,1,1,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (5,3,1,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (6,3,2,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (7,1,3,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (8,1,4,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (9,1,5,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (10,3,3,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (11,3,4,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (12,3,5,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (13,25,3,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (14,25,4,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (15,25,5,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (16,25,1,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (17,25,2,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (18,24,3,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (19,24,4,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (20,24,5,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (21,26,6,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (22,26,7,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (23,25,6,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (24,25,7,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (25,27,8,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (26,27,9,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (27,27,10,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (28,27,11,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (29,27,12,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (30,27,13,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (31,27,14,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (32,27,15,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (33,27,16,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (37,28,17,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (36,23,17,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (38,28,1,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (39,28,2,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (40,27,17,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (41,23,18,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (42,27,18,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (43,28,18,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (44,1,17,NULL);
insert  into `_tblProjectAssign`(`AssignID`,`UserID`,`ProjectID`,`AddedOn`) values (45,3,17,NULL);

/*Table structure for table `_tblProjects` */

DROP TABLE IF EXISTS `_tblProjects`;

CREATE TABLE `_tblProjects` (
  `ProjectID` int(11) NOT NULL AUTO_INCREMENT,
  `ProjectName` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`ProjectID`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `_tblProjects` */

insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (1,'Trip78-Web');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (2,'Trip78-MobileWeb');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (3,'tksd-MobileWeb');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (4,'abj-MobileWeb');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (5,'masflower-webapp');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (6,'lakshtex-ecomm');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (7,'lakshtex-mlm');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (8,'klx.co.in');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (9,'klxmart.com');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (10,'kasupanamthuttu.com');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (11,'rhole.in');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (12,'nammamarriage.com');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (13,'cinemanewfaces');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (14,'digitalmaking');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (15,'kingfish');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (16,'shippingtech');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (17,'Jewell-app');
insert  into `_tblProjects`(`ProjectID`,`ProjectName`) values (18,'Trip78-Webadmin');

/*Table structure for table `_tblPrototype` */

DROP TABLE IF EXISTS `_tblPrototype`;

CREATE TABLE `_tblPrototype` (
  `PrototypeID` int(11) NOT NULL AUTO_INCREMENT,
  `PrototypePostedBy` int(11) DEFAULT NULL,
  `PrototypePostedByName` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `PrototypeCreatedOn` datetime DEFAULT NULL,
  `PrototypeStatus` int(11) DEFAULT NULL COMMENT '1-Open 2 Close',
  `ProjectID` int(11) DEFAULT NULL,
  `ProjectName` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `PrototypeTitle` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `PrototypeDescription` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `CompletedOn` date DEFAULT NULL,
  `CompletedByID` int(11) DEFAULT NULL,
  `CompletedByName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`PrototypeID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `_tblPrototype` */

/*Table structure for table `_tblTaskConversation` */

DROP TABLE IF EXISTS `_tblTaskConversation`;

CREATE TABLE `_tblTaskConversation` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DeveloperID` int(11) DEFAULT NULL,
  `DeveloperName` varchar(255) DEFAULT NULL,
  `ConversationDate` datetime DEFAULT NULL,
  `Description` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `_tblTaskConversation` */

/*Table structure for table `_tblUser` */

DROP TABLE IF EXISTS `_tblUser`;

CREATE TABLE `_tblUser` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `EmployeeName` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `EmailAddress` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Password` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `IsAdmin` int(11) DEFAULT '0',
  `IsTester` int(11) DEFAULT '0',
  `IsDeveloper` int(11) DEFAULT '0',
  `IsStakeHolder` int(11) DEFAULT '0',
  `telegramid` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL,
  `OrgAdmin` int(11) DEFAULT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `_tblUser` */

insert  into `_tblUser`(`UserID`,`EmployeeName`,`EmailAddress`,`Password`,`CreatedOn`,`IsAdmin`,`IsTester`,`IsDeveloper`,`IsStakeHolder`,`telegramid`,`CreatedBy`,`OrgAdmin`) values (1,'Jeyaraj','jeyaraj_123@yahoo.com','02021982','2018-03-12 00:00:00',1,0,0,0,NULL,NULL,NULL);
insert  into `_tblUser`(`UserID`,`EmployeeName`,`EmailAddress`,`Password`,`CreatedOn`,`IsAdmin`,`IsTester`,`IsDeveloper`,`IsStakeHolder`,`telegramid`,`CreatedBy`,`OrgAdmin`) values (3,'Jayanthi','Jayanthi','123456',NULL,0,0,1,0,NULL,NULL,NULL);
insert  into `_tblUser`(`UserID`,`EmployeeName`,`EmailAddress`,`Password`,`CreatedOn`,`IsAdmin`,`IsTester`,`IsDeveloper`,`IsStakeHolder`,`telegramid`,`CreatedBy`,`OrgAdmin`) values (23,'Vickneswari ','vickneswari ','vickneswari ','2020-11-28 00:00:00',0,1,0,0,'',28,0);
insert  into `_tblUser`(`UserID`,`EmployeeName`,`EmailAddress`,`Password`,`CreatedOn`,`IsAdmin`,`IsTester`,`IsDeveloper`,`IsStakeHolder`,`telegramid`,`CreatedBy`,`OrgAdmin`) values (24,'tksd','maajidmultimart@gmail.com','tksd@786','2020-11-30 00:00:00',0,1,0,0,NULL,NULL,NULL);
insert  into `_tblUser`(`UserID`,`EmployeeName`,`EmailAddress`,`Password`,`CreatedOn`,`IsAdmin`,`IsTester`,`IsDeveloper`,`IsStakeHolder`,`telegramid`,`CreatedBy`,`OrgAdmin`) values (25,'Subbu','subbu@j2jsoftwaresolutio','subbu@2020','2020-11-30 00:00:00',0,0,1,0,NULL,NULL,NULL);
insert  into `_tblUser`(`UserID`,`EmployeeName`,`EmailAddress`,`Password`,`CreatedOn`,`IsAdmin`,`IsTester`,`IsDeveloper`,`IsStakeHolder`,`telegramid`,`CreatedBy`,`OrgAdmin`) values (28,'Raja','raja','raja','0000-00-00 00:00:00',0,1,0,0,'685405236',1,1);
insert  into `_tblUser`(`UserID`,`EmployeeName`,`EmailAddress`,`Password`,`CreatedOn`,`IsAdmin`,`IsTester`,`IsDeveloper`,`IsStakeHolder`,`telegramid`,`CreatedBy`,`OrgAdmin`) values (26,'Abdul','Abdul','Abdul','2020-11-30 00:00:00',0,1,0,0,NULL,28,0);
insert  into `_tblUser`(`UserID`,`EmployeeName`,`EmailAddress`,`Password`,`CreatedOn`,`IsAdmin`,`IsTester`,`IsDeveloper`,`IsStakeHolder`,`telegramid`,`CreatedBy`,`OrgAdmin`) values (27,'keju','keju','nagercoil123','2020-11-30 00:00:00',0,1,0,0,NULL,NULL,NULL);

/*Table structure for table `_tbltasklist` */

DROP TABLE IF EXISTS `_tbltasklist`;

CREATE TABLE `_tbltasklist` (
  `TaskID` int(11) NOT NULL AUTO_INCREMENT,
  `TaskPostedBy` int(11) DEFAULT NULL,
  `TaskPostedByName` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `TaskCreatedOn` datetime DEFAULT NULL,
  `TaskAssignedTo` int(11) DEFAULT NULL,
  `TaskAssignedByName` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `TaskAssignedOn` datetime DEFAULT NULL,
  `TaskStatus` int(11) DEFAULT NULL COMMENT '1-Open 2 Close',
  `ProjectID` int(11) DEFAULT NULL,
  `ProjectName` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `TaskTitle` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `TaskDescription` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `CompletedOn` date DEFAULT NULL,
  `CompletedByID` int(11) DEFAULT NULL,
  `CompletedByName` varchar(255) DEFAULT NULL,
  `EstimatedHours` varchar(255) DEFAULT NULL,
  `CompletedHours` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`TaskID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `_tbltasklist` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
