<!DOCTYPE html>
<html>
<head><meta charset="utf8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1"><title>IMax - Best Software Development Company in Tirunelveli</title>
<meta name="description" content="We are leading Software Company in Tirunelveli India with web development and Design">
<link rel="icon" href="favicon.ico" type="image/x-icon">
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 

<link type="text/css" rel="stylesheet" href="main.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,800,700,600,300' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="screen">	

<script src="https://use.fontawesome.com/6ca70c64ef.js"></script>

		
	<link rel="stylesheet" type="text/css" href="css/style.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="screen">
<link rel="stylesheet" type="text/css" href="css/custom.css" media="screen">



</head>

<body>