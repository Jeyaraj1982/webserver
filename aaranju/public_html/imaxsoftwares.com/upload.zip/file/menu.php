
<header role="banner" class="navbar navbar-fixed-top navbar-inverse">
      <div class="container">
	  
	   <div class="col-xs-6 col-sm-2 col-md-2 col-lg-2"> <a class="navbar-brand" href="#"><img src="images/logo.png" class="img-responsive"></a></div>
   
	   <div class=" col-sm-10 col-md-8 col-lg-8 pull-right">
	  
        <div class="navbar-header">
          <button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        </div>
        <div class="navbar-inverse side-collapse in">
          <nav role="navigation" class="navbar-collapse">
            <ul class="nav navbar-nav">
     <li class="active"><a href="index.php"> HOME</a> </li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="services.php">SERVICES</a></li>
<li><a href="promotion.php">PROMOTIONS</a></li>

<li ><a href="contact.php" >CONTACT US</a></li>
  
    
            </ul>
          </nav>
        </div>
      </div>
    </header>
