<div class="divider40"></div>
		
 <footer id="footer" class="style4">

            <div class="footer-wrapper">
                <div class="container">
                    <div class="row add-clearfix same-height">
                                <div class="col-sm-6 col-md-3" >
                            <h5 class="section-title box">STAY IN TOUCH</h5>
                            
                   
                            <p>We are always ready to help you. There are many ways to contact us. 
							You may drop us a line, give us a call . </p>
                   
                            <a href="contact.php" class="btn btn-sm style4">Contact Us</a>
						

        <div class="text-center center-block1">
           <div class="colour a">
            <br />
                <a href="https://www.facebook.com/"><i id="social-fb" class="fa fa-facebook-square fa-3x social"></i></a>
	            <a href="https://twitter.com/"><i id="social-tw" class="fa fa-twitter-square fa-3x social"></i></a>
	            <a href="https://plus.google.com/"><i id="social-gp" class="fa fa-google-plus-square fa-3x social"></i></a>
	            <a href="https://www.linkedin.com/" title="Linkedin"><i class="fa fa-linkedin-square fa-3x social icoLinkedin"></i></a>
</div></div>
   

						</div>
     
                        <div class="col-sm-6 col-md-3" >
                            <h5 class="section-title box">SERVICES</h5>
                            <ul class="arrow useful-links">
                                <li><a href="services.php">Software Development</a></li>
                                <li><a href="services.php">Web Application</a></li>
                                <li><a href="services.php">Mobile Application</a></li>
                                <li><a href="services.php">Design Service</a></li>
                                
                                
                                <li><a href="promotion.php">SEO</a></li>
                            </ul>
                        </div>
     
                        <div class="col-sm-6 col-md-3" >
                            <h5 class="section-title box">ERP DEVELOPMENT</h5>
                            <ul class="arrow useful-links">
								<li><a href="#">Hospital</a></li>
								<li><a href="#">Pharma & Chemicals</a></li>
								<li><a href="#">Trading</a></li>
                                <li><a href="#">Textile</a></li>
                                <li><a href="#">Supermarket</a></li>
                             
                               
                            </ul>
                            
                        </div>
                        <div class="col-sm-6 col-md-3"  >
                            <h5 class="section-title box">ABOUT IMAX</h5>
                            <p>
							We believe in the power of creativity. And we take a creative approach to address the needs of a better tomorrow. Our philosophy is to power creative solutions.</p>
                   
                   
                            <a href="about.php" class="btn btn-sm style4">About Us</a>
                          
                        </div>
						
                    </div>
					
					
					
					
					
					
					
					
					
                </div>
            </div>

			            <div class="container">
			            <div class="bottom-footer">
                <div class="row">
                    <div class="col-md-5">
                        <p class="small-text">&copy; Copyright 2018.<a href="http://imaxsoftwares.com/">Imax Softwares</a></p>
                    </div> <!-- /.col-md-5 -->
                    <div class="col-md-7">
					 <div class="colour a">
                        <ul class="footer-nav">
                            <li><a href="index.php">Home</a></li>
                           <li><a href="about.php">About Us</a></li>
                            <li><a href="services.php">Services</a></li>
                            </li>
                            <li><a href="promotion.php">Promotions</a></li>
                            
                            <li><a href="contact.php">Contact Us</a></li>
                        </ul>
						</div>
                    </div> <!-- /.col-md-7 -->
                </div> <!-- /.row -->
            </div> <!-- /.bottom-footer -->
            </div> <!-- /.bottom-footer -->
			
			
			
			
        </footer>
	
	

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	
	<script>
	
	$(document).ready(function() {   
            var sideslider = $('[data-toggle=collapse-side]');
            var sel = sideslider.attr('data-target');
            var sel2 = sideslider.attr('data-target-2');
            sideslider.click(function(event){
                $(sel).toggleClass('in');
                $(sel2).toggleClass('out');
            });
        });
	</script>
	
	
 </body></html>