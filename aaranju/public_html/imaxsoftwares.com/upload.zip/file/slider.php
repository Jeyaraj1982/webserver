<div class="container-fluid no-padding p-60">
 
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <a href="#"><img src="images/slider/slider0.jpg" alt="Software App Development" ></a>
      </div>

      <div class="item">
        <a href="#"><img src="images/slider/slider2.jpg" alt="Mobile App Development" ></a>
      </div>
    
      <div class="item">
       <a href="#"> <img src="images/slider/slider1.jpg" alt="ERP Development Company" ></a>
      </div>
      <div class="item">
       <a href="#"> <img src="images/slider/slider4.jpg" alt="SEO Development" ></a>
      </div>
    </div>

  </div>
</div>
