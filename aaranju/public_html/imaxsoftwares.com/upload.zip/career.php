
<?php include("file/header.php"); ?>
 <?php include("file/menu.php"); ?>
 
<div class="home">
   <div class="smallbanner-abt">
<div class="container">
  <div >Career<br>

</div> </div></div> 
	

	

			<div class="divider30"></div>
		

						 <div class="col-md-12 separator-info" >
                        <h3  >Career At iMAX Softwares</h3>
                    </div>
			<div class="divider60"></div>
												
			<div class="container">
     <div class="contact-block">
      <div class="row">
        <div class="col-md-5">
        
       <!-- <h4><i class="fa fa-map-marker "></i>&nbsp; Contact Address</h4><div class="divider"></div> -->
       <!-- <p style="padding-left:25px">IMAX SOFTWARES<br> -->
<!-- M.K.M BUILDING, IST FLOOR, <br> -->
 <!-- NEAR S.D.A SCHOOL<br> -->
<!-- PULIYAN KUDI -627 755 <br> -->
<!-- THIRUNELVELI DISTRICT <br> -->
<!-- TAMIL NADU <br> -->
<!-- INDIA </p> -->


<!-- <div class="divider"></div> -->
			<!-- <h4><i class="fa fa-pie-chart"></i>&nbsp; phone</h4><div class="divider"></div> -->
            <!-- <p style="padding-left:25px"> -->
 <!-- &nbsp; Mobile : +91 9786134505</p> -->

<div class="divider"></div>
<h4>Hello!</h4><div class="divider"></div>
   <p style="padding-left:25px" >       
 We are always interested in hearing from qualified, capable, motivated and enthusiastic team players.</p>

  
        </div>
        <div class="col-md-7 right">
          <form role="form">
         <div class=" form-group col-md-12 col-sm-12 col-xs-12 padding0">
      <div class="input-group">
         <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
         <input type="text" class="form-control" name="name" required="" placeholder="Name">
      </div>
      </div>
         
          <div class=" form-group col-md-12 col-sm-12 col-xs-12 padding0">
	   <div class="input-group">
         <span class="input-group-addon"><i class="fa fa-phone fa-fw"></i></span>
         <input type="tel" class="form-control" name="phone" placeholder="Phone No.">
      </div>
      </div>
         
			
			<div class="col-md-12 col-sm-12 col-xs-12 form-group padding0">
	   <div class="input-group">
         <span class="input-group-addon"><i class="fa fa-envelope fa-fw"></i></span>
         <input type="email" class="form-control" name="email" required="" placeholder="E-mail">
      </div>
      </div>
			
			<div class=" form-group col-md-12 col-sm-12 col-xs-12 padding0">
	   <div class="">
	  <select name="inquiry" required="" class="form-control">
  <option value="">Post for apply</option><option value="Web Designer">Web Designer</option><option value="Web Developer">Web Developer</option><option value="Mobile App Developer">Mobile App Developer</option><option value="Graphic Designer">Graphic Designer</option><option value="Seo specialist">SEO Specialist</option><option value="Ecommerce Developmer">Ecommerce Developer</option>
  <option value="Java Developer">Java Developer</option>
  <option value="Application Developer">Application Developer</option>
  <option value="HR Manager">HR Manager</option>
  <option value="Others">Others</option>
</select>
</div>
</div>
			
			<div class="col-md-12 form-group ">
	   <div class="input-group">
         <label> Upload your Resume: </label>
         <input type="file" name="fileToUpload" required="">
      </div>
      </div>
			
			
            <div class="col-md-12 form-group">
              <textarea placeholder="message"></textarea>
            </div>
            <div class="submit" >
              <a href="#" class="btn btn-info">submit now</a>
            </div>
          </form>
        </div>
      </div>
      <!-- row -->
    </div>
  </div>	
			
			
<div class="divider60"></div>
				
													
		

		</div><!--End Content Container -->
	
		


        </div>


  
<?php include("file/footer.php"); ?>