<?php include("file/header.php"); ?>
 <?php include("file/menu.php"); ?>
	

<div class="home">
   <div class="smallbanner-abt">
<div class="container"><div class="col-lg-12">
  <div >Promotions<br>

</div> </div></div> </div> 
	

	<div class="divider30"></div>
	<div class="recent-case-two-style padding-top-bottom">
            <div class="container">
                <div class="row">
               
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="single-studies">
                            <div class="studies-image">
                                <img src="images/promotion/case2_1.jpg" width="376" height="236" alt="case1">
                            </div>
                             <div class="studies-content case1 col-xs-12">
                                <h3><a>SEO</a></h3>
                                <p>We are a leading SEO company in Tirunelveli Tamil Nadu. India and have a team of world’s top notch SEO experts working for us who can meet your business goals. Whether you already have a website or just started to create a new website, we can help you with all SEO services in Tirunelveli,Tamil Nadu or even if you are located in some other part of world.
								</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="single-studies off-on">
                            
                            <div class="studies-content case2 ">
                                <h3><a>Social Media Optimization</a></h3>
                                <p>Social Media Optimization includes adding RSS feed, blogging and forums, where people are free to express their views and can comment on each other posts. Social networking websites have proven to be very popular in the past few years and the opportunity to use them for search engines, business promotion, online marketing and website promotion is very interesting. .</p>
                            </div>
                            <div class="studies-image">
                                <img src="images/promotion/case2_2.jpg" width="376" height="236" alt="case1">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="single-studies">
                            <div class="studies-image">
                                <img src="images/promotion/case2_3.jpg" width="376" height="236" alt="case1">
                            </div>
                            <div class="studies-content case3">
                                <h3><a>Facebook Promotion</a></h3>
                                <p>Facebook Ads marketing helps attract more customers by displaying your advertisements on Facebook. This opens your business to millions of active online users thus providing you a competitive edge. We believe in delivering high Returns on Investment (ROI) through constant monitoring, testing and better targeting of keywords. No matter what your budget is and whether you have short term or long term goals, we can manage your campaign so that you get the maximum returns on investment.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	
	
<div class="recent-case-two-style padding-top-bottom">
            <div class="container">
                <div class="row">
               
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="single-studies">
                            <div class="studies-image">
                                <img src="images/promotion/case2_33.jpg" width="376" height="236" alt="case1">
                            </div>
                            <div class="studies-content case1 col-xs-12">
                                <h3><a>Google Adwords Marketing</a></h3>
                                <p>Rank Getter is a premier Pay Per Click (PPC) marketing company known for its dedicated professionals and extensive industry experience. We believe in delivering high Returns on Investment (ROI) through constant monitoring, testing and better targeting of keywords. No matter what your budget is and whether you have short term or long term goals, we can manage your campaign so that you get the maximum returns on investment. 
								</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="single-studies off-on">
                            
                            <div class="studies-content case2">
                                <h3><a>Web Advertisement</a></h3>
                                <p>Get Your Advertisements reach within Minutes in Google, Yahoo, Bing, Facebook without the need of Search Engine Optimization and Search Engine Marketing!! It is faster to reach the right people in right place as much as soon when compared to other traditional media advertisements. </p>
                            </div>
                            <div class="studies-image">
                                <img src="images/promotion/case2_4.jpg" width="376" height="236" alt="case1">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="single-studies">
                            <div class="studies-image">
                                <img src="images/promotion/case2_5.jpg" width="376" height="236" alt="case1">
                            </div>
                            <div class="studies-content case3">
                                <h3><a>Digital Consulting</a></h3>
                                <p>In the fast changing online world your website and online marketing strategy requires constant modifications to maintain a leading edge. Be it adapting to the new search engine algorithms, running effective online advertisement campaigns, targeting right social media channels or keeping up with the latest web designs technologies it requires constant tweaking to remain competitive in online media.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	
	
	
	
<?php include("file/footer.php"); ?>
 