
<?php include("file/header.php"); ?>
 <?php include("file/menu.php"); ?>
 
<div class="home">
   <div class="smallbanner-abt">
<div class="container">
  <div >Contact<br>

</div> </div></div> 
	

	

			<div class="divider30"></div>
		

						 <div class="col-md-12 separator-info" >
                        <h3  >iMAX Softwares Contact Information</h3>
                    </div>
			<div class="divider60"></div>
												
			<div class="container">
     <div class="contact-block">
      <div class="row">
        <div class="col-md-5">
        
       <!-- <h4><i class="fa fa-map-marker "></i>&nbsp; Contact Address</h4><div class="divider"></div> -->
       <!-- <p style="padding-left:25px">IMAX SOFTWARES<br> -->
<!-- M.K.M BUILDING, IST FLOOR, <br> -->
 <!-- NEAR S.D.A SCHOOL<br> -->
<!-- PULIYAN KUDI -627 755 <br> -->
<!-- THIRUNELVELI DISTRICT <br> -->
<!-- TAMIL NADU <br> -->
<!-- INDIA </p> -->


<!-- <div class="divider"></div> -->
			<!-- <h4><i class="fa fa-pie-chart"></i>&nbsp; phone</h4><div class="divider"></div> -->
            <!-- <p style="padding-left:25px"> -->
 <!-- &nbsp; Mobile : +91 9786134505</p> -->

<div class="divider"></div>
<h4><i class="fa fa-life-ring"></i>&nbsp; Support</h4><div class="divider"></div>
   <p style="padding-left:25px" >       
 &nbsp; Email : info@imaxsoftwares.com</p>

  
        </div>
        <div class="col-md-7 right">
          <form role="form">
            <div class="col-md-6 form-group">
              <input type="email" class="form-control" placeholder="First Name">
            </div>
            <div class="col-md-6 form-group">
              <input type="email" class="form-control" placeholder="Last Name">
            </div>
            <div class="col-md-6 form-group">
              <input type="text" class="form-control"  placeholder="Email">
            </div>
            <div class="col-md-6 form-group">
              <input type="text" class="form-control"  placeholder="Website">
            </div>
            <div class="col-md-12 form-group">
              <textarea placeholder="message"></textarea>
            </div>
            <div class="submit" >
              <a href="#" class="btn btn-info">submit now</a>
            </div>
          </form>
        </div>
      </div>
      <!-- row -->
    </div>
  </div>	
			
			

				
													
		

		</div><!--End Content Container -->
	
		


        </div>
<?php include("file/footer.php"); ?>


					     