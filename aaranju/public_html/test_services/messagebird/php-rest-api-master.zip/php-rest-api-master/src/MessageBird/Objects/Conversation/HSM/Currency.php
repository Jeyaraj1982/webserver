<?php

namespace MessageBird\Objects\Conversation\HSM;

class Currency
{
    /**
     * @var string $code
     */
    public $code;

    /**
     * @var int $amount
     */
    public $amount;
}