<?php
namespace MessageBird\Exceptions;

/**
 * Class MessageBirdException
 *
 * @package MessageBird\Exceptions
 */
abstract class MessageBirdException extends \Exception
{

}
