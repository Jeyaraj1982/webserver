<?php
    include_once("config.php");
    include_once("includes/header.php");
?>
   <main role="main">
      <!-- Content -->
      <article>
        <header class="section background-primary background-transparent text-center"  data-image-src="assets/img/parallax-02.jpg" style="padding:50px !important">
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1">Cancellation Policy</h1>
            <div class="background-parallax" style="background-image:url(assets/img/parallax-06.jpg)"></div>
        </header>
        <div class="section background-white"> 
          <div class="line">
            <h2 class="text-size-30">Investigationes demonstraverunt lectores</h2>
            <hr class="break break-small background-primary">
            <p>
            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. 
            Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. 
            Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros 
            et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.
            </p> 
            <blockquote class="margin-top-bottom-20">
              Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima.
            </blockquote>
            <p class="margin-bottom-30">
            Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; 
            est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. 
            Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc 
            putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc 
            nobis videntur parum clari, fiant sollemnes in futurum.
            </p>
            <div class="line">
              <div class="margin">
                <div class="s-12 m-12 l-6 margin-m-bottom-30">
                  <h2>Mirum est notare quam littera gothica</h2>
                  <p>
                  Typi non habent claritatem insitam est usus legentis in iis qui facit eorum claritatem. 
                  Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. 
                  Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.
                  </p>
                </div>
                <div class="s-12 m-12 l-6">
                  <h2>Claritas est etiam processus dynamicus</h2>
                  <p>
                  Typi non habent claritatem insitam est usus legentis in iis qui facit eorum claritatem. 
                  Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. 
                  Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.
                  </p>
                </div>
              </div>  
            </div>
          </div>
          
        
    </main>
    
<?php
        include_once("includes/footer.php");
    ?>    