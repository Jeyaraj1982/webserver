<?php
    $_SESSION['param']=array();
?>
<div class="container-fluid" style="padding:25px;">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div style="text-align:center;padding:100px;">
                                    <img src="assets/images/shield.png"><br><br>
                                    <span style='color:green'>Stock Point Created Successfully.</span> 
                                    <br><br>
                                    <a href="dashboard.php?action=Stockiest/ManageStockPoints">Continue</a>
                                     
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</div>            