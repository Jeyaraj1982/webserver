<div class="row mb15">
    <div class="col-md-12 col-xs-12 b-r">
        <a href="dashboard.php?action=Settings/GeneralSettings">General Settings</a>
    </div>
</div>
<div class="row mb15">
    <div class="col-md-12 col-xs-12 b-r">
        <a href="dashboard.php?action=Settings/EnrollmentPackage">Enrollment Packages</a>
    </div>
</div>
<div class="row mb15">
    <div class="col-md-12 col-xs-12 b-r">
        <a href="dashboard.php?action=Settings/WithdrawalSettings">Withdrawal Settings</a>
    </div>
</div>
<div class="row mb15">
    <div class="col-md-12 col-xs-12 b-r">
        <a href="dashboard.php?action=Settings/PayoutSettings">Payout Settings</a>
    </div>
</div>
<div class="row mb15">
    <div class="col-md-12 col-xs-12 b-r">
        <a href="dashboard.php?action=Settings/MobileAPISettings">Mobile SMS API Settings</a>
    </div>
</div>  
<div class="row mb15">
    <div class="col-md-12 col-xs-12 b-r">
        <a href="dashboard.php?action=Settings/SMTP">SMTP Settings</a>
    </div>
</div>
<div class="row mb15">
    <div class="col-md-12 col-xs-12 b-r">
        <a href="dashboard.php?action=Settings/Whatsapp">Whatsapp Settings</a>
    </div>
</div>
<div class="row mb15">
    <div class="col-md-12 col-xs-12 b-r">
        <a href="dashboard.php?action=Settings/DoubleAuthentication">Double Authentication Settings</a>
    </div>
</div>
 