<div style="padding:25px">
    <div class="page-header">
        <ul class="breadcrumbs" style="border: none;padding-left: 0px;margin-left: 0px;">
            <li class="nav-home"><a href="dashboard.php"><i class="flaticon-home"></i></a></li>
            <li class="separator"><i class="flaticon-right-arrow"></i></li>
            <li class="nav-item"><a href="dashboard.php?action=Members/CreateMember">Members</a></li>
            <li class="separator"><i class="flaticon-right-arrow"></i></li>
            <li class="nav-item"><a href="dashboard.php?action=Members/CreateMember">Create Member</a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Create Member</div>
                </div>
                <div class="card-body">
                    <span style='color:red'>Error: Tree Conflit, Please contact administrator.</span> <br>
                    Click here to <a href='dashboard.php?action=Members/CreateMember>'>Continue</a>
                </div>
            </div>
        </div>
    </div>
</div>