http://demo.themekita.com/atlantis/livepreview/examples/demo1/


http://demo.themekita.com/atlantis/livepreview/examples/assets/fonts/fontawesome/fa-brands-400.svg
http://demo.themekita.com/atlantis/livepreview/examples/assets/fonts/fontawesome/fa-regular-400.svg
http://demo.themekita.com/atlantis/livepreview/examples/assets/fonts/fontawesome/fa-solid-900.eot
http://demo.themekita.com/atlantis/livepreview/examples/assets/fonts/simple-line-icons/Simple-Line-Icons.svg
http://demo.themekita.com/atlantis/livepreview/examples/assets/fonts/flaticon/Flaticon.svg

