<?php

return [
    'home' => [
        'title' => 'GG Cash',
        'keywords' => '',
        'description' => '',
    ],
    'send' => [
        'title' => 'Send Money',
        'keywords' => '',
        'description' => '',
		
    ],
	'receive' => [
        'title' => 'Recive Money',
        'keywords' => '',
        'description' => '',
    ],
    
    
	'about-us' => [
        'title' => 'About Us',
        'keywords' => '',
        'description' => '',
    ],
    
	'contact-us' => [
        'title' => 'Contact Us -',
        'keywords' => '',
        'description' => '',
    ],
	'support' => [
        'title' => 'Support',
        'keywords' => '',
        'description' => '',
    ],
	'how-it-works' => [
        'title' => 'How It Works',
        'keywords' => '',
        'description' => '',
    ],
	'faq' => [
        'title' => 'FAQ',
        'keywords' => '',
        'description' => '',
    ],
    
    'login' => [
        'title' => 'login',
        'keywords' => '',
        'description' => '',
    ],
    
    'signup' => [
        'title' => 'signup',
        'keywords' => '',
        'description' => '',
    ],
    
    
    
	
];
