
  <!-- Content
  ============================================= -->
  <div id="content">
  <div class="login-signup-page mx-auto my-5">
      <h3 class="font-weight-400 text-center">Sign Up</h3>
      <p class="lead text-center">Your Sign Up information is safe with us.</p>
      <div class="bg-light shadow-md rounded p-4 mx-2">
      <form id="signupForm" method="post">
                <div class="form-group">
                  <label for="fullName">Full Name</label>
                  <input type="text" class="form-control" id="fullName" required placeholder="Enter Your Name">
                </div>
                <div class="form-group">
                  <label for="emailAddress">Email Address</label>
                  <input type="email" class="form-control" id="emailAddress" required placeholder="Enter Your Email">
                </div>
                <div class="form-group">
                  <label for="loginPassword">Password</label>
                  <input type="password" class="form-control" id="loginPassword" required placeholder="Enter Password">
                </div>
                <button class="btn btn-primary btn-block my-4" type="submit">Sign Up</button>
              </form>
      <p class="text-3 text-muted text-center mb-0">Already have an account? <a class="btn-link" href="login-3.html">Log In</a></p>
    </div>
    </div>
  <!-- Content end -->
 