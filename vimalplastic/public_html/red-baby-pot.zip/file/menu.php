<!-- Main Header Start -->
	<header class="my-main-header my-main-header-three"> 
		<div class="my-header-top-bar hidden-xs">
			<div class="container">
				<div class="row">
					<div class="col-md-5 col-sm-4">
						<div class="my-header-top-col my-text-center">
							
<p><i class="fa fa-envelope" aria-hidden="true"></i>kabali702013@gmail.com</p>
						</div>
					</div>
					<div class="col-md-2 col-md-offset-2 col-sm-4">
						<div class="my-header-top-col my-text-center">
							<p><i class="fa fa-phone" aria-hidden="true"></i>+91 98658 76301</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-4">
						<div class="my-header-top-col text-right my-text-center">
							<a href="enquiry.php"><button class="btn btn-default" type="submit"><i class="fa fa-globe" aria-hidden="true"></i> Get a quote</button></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="my-header-nav">
			<div class="my-main-nav scrollingto-fixed" style="z-index: auto; position: static; top: auto;">
				<nav class="navbar navbar-default bootsnav my-menu-style-three yellow on no-full">
				    <!-- Start Top Search -->
				    <div class="top-search">
				        <div class="container">
				            <div class="input-group">
				                <span class="input-group-addon"><i class="fa fa-search"></i></span>
				                <input type="text" class="form-control" placeholder="Search">
				                <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
				            </div>
				        </div>
				    </div>
				    <!-- End Top Search -->
			        <div class="container my-container-three">
			            <!-- Start Header Navigation -->
			            <div class="navbar-header">
			                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
			                    <i class="fa fa-bars"></i>
			                </button>
			                <a class="navbar-brand" href="index.php"><img src="images/header-logo-3.png" class="my-logo-3" alt=""></a>
			            </div>
			            <!-- End Header Navigation -->
			            <!-- Collect the nav links, forms, and other content for toggling -->
			            <div class="collapse navbar-collapse my-container-three" id="navbar-menu">
			                <ul class="nav navbar-nav navbar-left" data-in="fadeIn">
			                    <li>
			                        <a href="index.php" class="<?php if($page=='home'){echo'active';}?>">Home</a>
			                        
			                    </li>
			                    <li>
			                        <a href="about.php" class="<?php if($page=='about'){echo'active';}?>">About Us</a>
			                    </li>
			                    <li>
			                        <a href="products.php" class="<?php if($page=='products'){echo'active';}?>">Products</a>
			                    </li>
			                    <li>
			                        <a href="gallery.php" class="<?php if($page=='gallery'){echo'active';}?>">Gallery</a>
			                    </li>
			                    <li>
			                        <a href="contact.php" class="<?php if($page=='contact'){echo'active';}?>">Contact Us</a>
			                    </li>
			                    <li>
			                        <a href="enquiry.php" class="<?php if($page=='enquiry'){echo'active';}?>">Enquiry Us</a>
			                    </li>
			                    
			                    
			                </ul>
				       
					        <!-- End Atribute Navigation -->
						</div>
					</div>
				</nav>
			</div><div style="display: none; width: 1583px; height: 79px; float: none;"></div>
		</div>
	</header>
	<!-- Main Header end -->
	